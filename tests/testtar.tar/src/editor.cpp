#include "editor.h"
#include <algorithm>
#include <chrono>
#include <format>
#include <fstream>
#include <functional>
#include <iostream>
#include <lsp/json/json.h>
#include <ncurses.h>
#include <sstream>
#include <thread>
#include <unordered_set>
#include "agentlib/ai_agent.h"
#include "agentlib/ai_model.h"
#include "binary_document.h"
#include "build_error_manager.h"
#include "codereview_manager.h"
#include "config_manager.h"
#include "session_manager.h"
#include "crashdump_manager.h"
#include "event_logger.h"
#include "fs_utils.h"
#include "gcc_log_parser.h"
#include "git_manager.h"
#include "history_manager.h"
#include "project_manager.h"
#include "utf8.h"
#include "line.h"
#include "filter_registry.h"
#include "tools/troff2md.h"
#include "ui/agent_center_window.h"
#include "ui/agent_window.h"
#include "ui/code_review_window.h"
#include "ui/crashdump_window.h"
#include "ui/dialog_factories.h"
#include "ui/diff_window.h"
#include "ui/hex_editor_window.h"
#include "ui/terminal_window.h"
#include "ui/components/ui_multiline_edit.h"
#include "input_history_manager.h"

namespace fs = std::filesystem;

editor::editor(editor_options opts)
    : exit_immediately_(opts.exit_immediately), debug_mode_(opts.debug_mode), debug_string_(std::move(opts.debug_string)),
      initial_agent_prompt_(std::move(opts.initial_agent_prompt)), fresh_agent_(opts.fresh_agent)
{
	ui_multiline_edit::set_global_queue(&global_queue_);
	// The troff_to_markdown filter parses manual page troff syntax and converts it to GitHub Flavored Markdown (GFM).
	// This filter is registered dynamically at editor startup rather than statically inside the filter registry to avoid
	// linking troff2md.cpp's AST parser functions into headless unit test binaries that don't need UI-related filters.
	agentlib::filter_registry::get_instance().register_filter("troff_to_markdown", [](const std::string &input) {
		return ::troff2md(input);
	}, {"text"});

	agentlib::filter_registry::get_instance().register_filter("to_markdown", [](const std::string &input) {
		std::string trimmed = input;
		trimmed.erase(0, trimmed.find_first_not_of(" \t\r\n"));

		bool detected_html = false;
		bool detected_troff = false;

		// 1. Try detecting format using libmagic
		std::string mime_str = utf8::detect_mime(input);
		if (!mime_str.empty()) {
			if (mime_str.find("html") != std::string::npos) {
				detected_html = true;
			} else if (mime_str.find("troff") != std::string::npos || mime_str.find("nroff") != std::string::npos || mime_str.find("x-man") != std::string::npos) {
				detected_troff = true;
			}
		}

		// 2. Fall back to existing heuristics if libmagic didn't detect or is disabled
		if (!detected_html && !detected_troff) {
			if (trimmed.starts_with("<html") || trimmed.starts_with("<!DOCTYPE") || trimmed.starts_with("<div") || trimmed.starts_with("<p>")) {
				detected_html = true;
			} else if (trimmed.starts_with(".SH") || trimmed.starts_with(".TH") || trimmed.starts_with(".PP") || trimmed.starts_with(".Dd") || trimmed.starts_with(".de")) {
				detected_troff = true;
			}
		}

		// 3. Delegate to sub-filters
		if (detected_html) {
			auto &registry = agentlib::filter_registry::get_instance();
			if (registry.has_filter("html_to_markdown")) {
				bool success = false;
				std::string result = registry.apply_filter("html_to_markdown", input, success);
				if (success) return result;
			}
		}

		if (detected_troff) {
			auto &registry = agentlib::filter_registry::get_instance();
			if (registry.has_filter("troff_to_markdown")) {
				bool success = false;
				std::string result = registry.apply_filter("troff_to_markdown", input, success);
				if (success) return result;
			}
		}

		return input;
	}, {"text", "web"});
	line::global_tab_width = config_manager::get_instance().get_tab_width();
	main_thread_id_ = std::this_thread::get_id();
	last_mtime_check_time_ = std::chrono::steady_clock::now();
	history_manager::get_instance().load();
	input_history_manager::get_instance().load();
	current_search_.query = session_manager::get_instance().get_last_search_query();
	current_search_.replacement = session_manager::get_instance().get_last_replace_query();
	git_manager::get_instance().start(global_queue_);
	bool lsp_allowed = !opts.no_lsp && config_manager::get_instance().is_lsp_enabled();
	if (lsp_allowed) {
		project_manager::get_instance().lsp_start(global_queue_);
	}

	std::string project_root = project_manager::get_instance().get_project_root();

	if (opts.filenames.empty()) {
		bool loaded_files = false;
		if (!opts.start_with_agent && !project_root.empty()) {
			std::vector<std::string> proj_files = history_manager::get_instance().get_project_files(project_root);
			if (!proj_files.empty()) {
				for (const auto &f : proj_files) {
					new_window(f);
				}
				loaded_files = true;
			}
		}

		if (!loaded_files) {
			if (opts.start_with_agent) {
				new_agent_window();
			} else {
				new_window("");
				if (!opts.no_welcome && initial_agent_prompt_.empty()) {
					active_dialog_ = create_welcome_dialog();
					active_dialog_mode_ = dialog_mode::welcome;
					set_focus(focus_target::dialog, "welcome");
				}
			}
		}
	} else {
		for (const auto &f : opts.filenames) {
			new_window(f);
		}
		if (opts.start_with_agent) {
			new_agent_window();
		}
	}

	// Check for previous crash
	std::string crash_text;
	std::string crash_file_path;
	try {
		namespace fs = std::filesystem;
		fs::path crash_dir = fs::path(fs_utils::get_global_cache_dir()) / "crashes";
		if (fs::exists(crash_dir)) {
			for (auto &p : fs::directory_iterator(crash_dir)) {
				if (p.is_regular_file() && p.path().filename().string().starts_with("crash_") && fs::file_size(p.path()) > 0) {
					crash_file_path = p.path().string();
					std::ifstream f(p.path());
					crash_text = std::string((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
					break;
				}
			}
		}
	} catch (...) {}

	if (!crash_text.empty()) {
		active_dialog_ = create_crash_dialog(crash_text, crash_file_path);
		active_dialog_mode_ = dialog_mode::crash_report;
		set_focus(focus_target::dialog, "crash_report");
	}
}

void editor::new_window(const std::string &filename)
{
	if (filename.empty()) {
		open_file_as_text("");
		return;
	}

	fs_utils::file_type_t type = fs_utils::get_file_type(filename);
	if (config_manager::get_instance().is_force_ascii()) {
		type = fs_utils::file_type_t::ASCII;
	}

	if (type == fs_utils::file_type_t::BINARY) {
		open_file_as_binary(filename);
	} else if (type == fs_utils::file_type_t::ASCII) {
		open_file_as_text(filename);
	} else { // MAYBE
		pending_open_filename_ = filename;
		active_dialog_ = create_maybe_binary_prompt_dialog(filename);
		active_dialog_mode_ = dialog_mode::maybe_binary_prompt;
		set_focus(focus_target::dialog, "maybe_binary_prompt");
	}
}

void editor::open_file_as_text(const std::string &filename)
{
	auto doc = std::make_shared<document>(global_queue_, filename);
	doc->add_listener(&codereview_manager::get_instance());
	auto win = std::make_unique<window>(static_cast<int>(windows_.size() + 1), 0, 1, COLS, LINES - 2, filename);
	win->attach_document(doc);

	documents_.push_back(doc);
	windows_.push_back(std::move(win));
	activate_window(windows_.size() - 1);
}

void editor::open_file_as_binary(const std::string &filename)
{
	auto bin_doc = std::make_shared<binary_document>(global_queue_, filename);
	auto win = std::make_unique<hex_editor_window>(static_cast<int>(windows_.size() + 1), 0, 1, COLS, LINES - 2, filename, bin_doc);

	documents_.push_back(bin_doc);
	windows_.push_back(std::move(win));
	activate_window(windows_.size() - 1);
}

void editor::open_prompt_in_editor(ui_multiline_edit *edit, const std::string &initial_text)
{
	std::string virtual_filename = "*Prompt*";

	// Check if already open
	for (size_t i = 0; i < windows_.size(); ++i) {
		auto doc = windows_[i]->get_document();
		if (doc && doc->get_filename() == virtual_filename) {
			edit->link_document(doc);
			activate_window(i);
			return;
		}
	}

	// Create virtual prompt document
	auto doc = std::make_shared<document>(global_queue_, virtual_filename);
	doc->clear();
	doc->insert_text(initial_text);
	doc->clear_modified();

	auto win = std::make_unique<window>(static_cast<int>(windows_.size() + 1), 0, 1, COLS, LINES - 2, virtual_filename);
	win->attach_document(doc);

	documents_.push_back(doc);
	windows_.push_back(std::move(win));
	activate_window(windows_.size() - 1);

	edit->link_document(doc);
}

void editor::new_diff_window()
{
	auto doc = get_active_doc();
	if (!doc)
		return;
	auto diff_win = std::make_unique<diff_window>(static_cast<int>(windows_.size() + 1), 0, 1, COLS, LINES - 2, doc, global_queue_);
	windows_.push_back(std::move(diff_win));
	update_window_layout();
	activate_window(windows_.size() - 1);
}

void editor::update_window_layout()
{
	int total_h = LINES - 2;
	event_logger::get_instance().log(std::format("Updating window layout: COLS={}, LINES={}, total_h={}", COLS, LINES, total_h));
	needs_full_redraw_ = true;
	int main_w = COLS;

	window *run_win = nullptr;
	window *gdb_win = nullptr;
	for (auto &win : windows_) {
		if (win->get_title() == "Run Output") {
			run_win = win.get();
		}
		if (win->get_title() == "Debugger (GDB)") {
			gdb_win = win.get();
		}
	}

	int app_h = (total_h * 2) / 3;
	int gdb_h = total_h - app_h;

	for (auto &win : windows_) {
		int target_x = 0;
		int target_y = 1;
		int target_w = main_w;
		int target_h = total_h;

		if (win.get() == run_win && gdb_win != nullptr) {
			target_h = app_h;
		} else if (win.get() == gdb_win && run_win != nullptr) {
			target_y = 1 + app_h;
			target_h = gdb_h;
		}

		if (win->is_maximized()) {
			if (win->get_document() == nullptr) {
				win->set_maximized(false);
				win->set_bounds(target_x, target_y, target_w, target_h);
				win->set_maximized(true);
			}
			win->set_bounds(0, 1, COLS, total_h);
		} else {
			if (win->get_document() == nullptr) {
				win->set_bounds(target_x, target_y, target_w, target_h);
			}
		}
		win->invalidate();
	}
}

void editor::new_agent_window()
{
	// Check if there is already an open main agent window
	for (size_t i = 0; i < windows_.size(); ++i) {
		if (auto aw = dynamic_cast<agent_window *>(windows_[i].get())) {
			if (auto agent = aw->get_agent()) {
				if (agent->get_parent() == nullptr) {
					activate_window(i);
					return;
				}
			}
		}
	}

	auto model = agentlib::ai_model_registry::get_instance().get_default_model();

	auto main_agent_win = std::make_unique<agent_window>(static_cast<int>(windows_.size() + 1), 0, 1, COLS, LINES - 2, model,
							     global_queue_, this, fresh_agent_);

	windows_.push_back(std::move(main_agent_win));

	update_window_layout();

	// Activate the main agent window
	activate_window(windows_.size() - 1);
}

void editor::new_agent_center_window()
{
	// Check if there is already an open agent center window
	for (size_t i = 0; i < windows_.size(); ++i) {
		if (dynamic_cast<agent_center_window *>(windows_[i].get())) {
			activate_window(i);
			return;
		}
	}

	auto center_win = std::make_unique<agent_center_window>(static_cast<int>(windows_.size() + 1), 0, 1, COLS, LINES - 2, this);
	windows_.push_back(std::move(center_win));
	update_window_layout();
	activate_window(windows_.size() - 1);
}

void editor::open_subagent_window(std::shared_ptr<agentlib::ai_agent> subagent)
{
	auto subagent_win =
	    std::make_unique<agent_window>(static_cast<int>(windows_.size() + 1), 0, 1, COLS, LINES - 2, std::move(subagent));

	windows_.push_back(std::move(subagent_win));
	update_window_layout();

	// Activate the new subagent window (it will be resized by update_window_layout)
	activate_window(windows_.size() - 1);
}

void editor::new_crashdump_window()
{
	auto dump_win = std::make_unique<crashdump_window>(static_cast<int>(windows_.size() + 1), 0, 1, COLS, LINES - 2, global_queue_);
	windows_.push_back(std::move(dump_win));
	update_window_layout();
	activate_window(windows_.size() - 1);
}

void editor::new_codereview_window(int focus_item_id)
{
	for (size_t i = 0; i < windows_.size(); ++i) {
		if (auto cr_win = dynamic_cast<code_review_window *>(windows_[i].get())) {
			if (focus_item_id > 0) {
				cr_win->focus_item(focus_item_id);
			}
			activate_window(i);
			return;
		}
	}

	auto cr_win = std::make_unique<code_review_window>(static_cast<int>(windows_.size() + 1), 0, 1, COLS, LINES - 2, global_queue_,
							   focus_item_id);
	windows_.push_back(std::move(cr_win));
	update_window_layout();
	activate_window(windows_.size() - 1);
}

void editor::activate_window(size_t index)
{
	if (index >= windows_.size())
		return;

	event_logger::get_instance().log(std::format("Selecting window: {}", index));
	for (size_t i = 0; i < windows_.size(); ++i) {
		windows_[i]->set_active(i == index);
	}
	update_window_layout();
	update_window_menu();
}

void editor::update_window_menu()
{
	std::vector<menu_item> items;

	items.push_back(menu_item("Close", event_type::close_window, 0, 'c', "Alt+F3", false));
	items.push_back(menu_item("", event_type::key_press, 0, 0, "", true)); // Separator

	for (size_t i = 0; i < windows_.size(); ++i) {
		std::string filename = windows_[i]->get_title();
		if (filename.empty())
			filename = "noname.txt";

		auto doc = windows_[i]->get_document();
		if (doc && doc->is_modified()) {
			filename += "*";
		}

		std::string name = std::to_string((i + 1) % 10) + " " + filename;

		std::string shortcut = "";
		char hotkey = 0;
		if (i < 10) {
			int num = static_cast<int>((i + 1) % 10);
			shortcut = "Alt-" + std::to_string(num);
			hotkey = static_cast<char>('0' + num);
		}

		items.push_back(menu_item(name, event_type::select_window, static_cast<int>(i), hotkey, shortcut, false));
	}
	event_logger::get_instance().log("update_window_menu: {} items", items.size());
	top_menu_.set_category_items("Window", items);

	auto active_doc = get_active_doc();
	bool read_only = (!active_doc || active_doc->is_read_only());
	top_menu_.set_item_disabled(event_type::save, read_only);
	top_menu_.set_item_disabled(event_type::save_as, read_only);
	top_menu_.set_item_disabled(event_type::save_all, read_only);
	top_menu_.set_item_disabled(event_type::run_program, config_manager::get_instance().get_main_executable().empty());
	top_menu_.set_item_disabled(event_type::run_in_debugger, config_manager::get_instance().get_main_executable().empty());
}

std::shared_ptr<document> editor::get_active_doc() const
{
	for (auto &w : windows_) {
		if (w->is_active()) {
			return w->get_document();
		}
	}
	if (!documents_.empty()) {
		return documents_[0];
	}
	return nullptr;
}

window *editor::get_active_window() const
{
	for (auto &w : windows_) {
		if (w->is_active()) {
			return w.get();
		}
	}
	return nullptr;
}

std::string editor::get_search_autocomplete() const
{
	if (search_input_buffer_.empty())
		return "";

	const auto &history = history_manager::get_instance().get_searches();
	for (const auto &item : history) {
		if (item.length() >= search_input_buffer_.length() &&
		    item.substr(0, search_input_buffer_.length()) == search_input_buffer_) {
			return item;
		}
	}
	return "";
}

namespace
{
class editor_document_snapshot : public agentlib::document_snapshot
{
      public:
	editor_document_snapshot(std::vector<std::string> lines, std::vector<diagnostic_info> diagnostics) : lines_(std::move(lines))
	{
		for (const auto &d : diagnostics) {
			agentlib::diagnostic_snapshot ds;
			ds.line = d.range.start_y;
			ds.column = d.range.start_x;
			ds.message = d.message;
			ds.source = "LSP";
			switch (d.severity) {
				case 1:
					ds.severity = "Error";
					break;
				case 2:
					ds.severity = "Warning";
					break;
				case 3:
					ds.severity = "Information";
					break;
				case 4:
					ds.severity = "Hint";
					break;
				default:
					ds.severity = "Unknown";
					break;
			}
			diagnostics_.push_back(ds);
		}
	}

	size_t get_line_count() const override
	{
		return lines_.size();
	}
	std::string get_line_text(size_t index) const override
	{
		if (index < lines_.size())
			return lines_[index];
		return "";
	}
	std::vector<agentlib::diagnostic_snapshot> get_diagnostics() const override
	{
		return diagnostics_;
	}

      private:
	std::vector<std::string> lines_;
	std::vector<agentlib::diagnostic_snapshot> diagnostics_;
};
} // namespace

std::vector<std::string> editor::get_open_document_paths() const
{
	std::vector<std::string> paths;
	for (const auto &doc : documents_) {
		std::string doc_path = doc->get_filename();
		if (doc_path.empty())
			continue;

		try {
			std::filesystem::path p = std::filesystem::weakly_canonical(doc_path);
			paths.push_back(p.string());
		} catch (...) {
			// Ignore invalid paths
		}
	}
	return paths;
}

std::unique_ptr<agentlib::document_snapshot> editor::get_open_document(const std::string &safe_path) const
{
	std::filesystem::path target_p(safe_path);
	for (const auto &doc : documents_) {
		std::string doc_path = doc->get_filename();
		if (doc_path.empty())
			continue;

		try {
			std::filesystem::path p(doc_path);
			if (std::filesystem::exists(p) && std::filesystem::exists(target_p)) {
				if (std::filesystem::equivalent(p, target_p)) {
					return std::make_unique<editor_document_snapshot>(doc->get_all_lines(), doc->get_diagnostics());
				}
			}

			// Fallback for non-existent files or if equivalent fails (e.g. relative vs absolute)
			if (std::filesystem::weakly_canonical(p).string() == std::filesystem::weakly_canonical(target_p).string()) {
				return std::make_unique<editor_document_snapshot>(doc->get_all_lines(), doc->get_diagnostics());
			}
		} catch (...) {
			// Ignore invalid paths
		}
	}
	return nullptr;
}

editor::~editor()
{
	project_manager::get_instance().set_exiting(true);
	project_manager::get_instance().lsp_stop();
	git_manager::get_instance().stop();
}

void editor::run()
{
	if (!initial_agent_prompt_.empty()) {
		new_agent_window();
		// Look for the agent window we just created to send the message
		for (auto &win : windows_) {
			if (auto agent_win = dynamic_cast<agent_window *>(win.get())) {
				if (auto agent = agent_win->get_agent()) {
					agent->submit_prompt(initial_agent_prompt_);
				}
				break;
			}
		}
		// Clear it so we don't send it again
		initial_agent_prompt_.clear();
	}

	render();

	// Set ncurses getch timeout to 50ms to allow background events to
	// process
	timeout(50);
	auto start_time = std::chrono::steady_clock::now();

	while (is_running_) {
		bool needs_render = false;
		bool needs_cursor_render = false;

		auto clock_now = std::chrono::system_clock::now();
		auto clock_min = std::chrono::duration_cast<std::chrono::minutes>(clock_now.time_since_epoch()).count();
		if (clock_min != last_clock_minute_) {
			last_clock_minute_ = clock_min;
			needs_render = true;
		}

		auto loop_now = std::chrono::steady_clock::now();
		int check_interval = 10;
		const char *env_interval = std::getenv("TURBOSTAR_MTIME_CHECK_INTERVAL");
		if (env_interval && *env_interval) {
			try {
				check_interval = std::stoi(env_interval);
			} catch (...) {
			}
		}
		if (std::chrono::duration_cast<std::chrono::seconds>(loop_now - last_mtime_check_time_).count() >= check_interval) {
			last_mtime_check_time_ = loop_now;
			check_files_changed();
		}
		if (exit_immediately_ >= 0.0) {
			auto now = std::chrono::steady_clock::now();
			if (std::chrono::duration_cast<std::chrono::milliseconds>(now - start_time).count() >
			    static_cast<long long>(exit_immediately_ * 1000.0)) {
				event_logger::get_instance().log("Application exit requested (source: --exit-immediately timer).");
				is_running_ = false;
			}
		}

		wint_t wch;
		int res = get_wch(&wch);

		// Record the start timestamp if we received a valid user input event
		// to measure interactive response latency.
		bool processed_event = false;
		std::chrono::steady_clock::time_point event_start;
		uint64_t start_log_seq = 0;
		if (res != ERR) {
			event_start = std::chrono::steady_clock::now();
			start_log_seq = event_logger::get_instance().get_total_event_count();
			processed_event = true;
		}

		// Handle dialog tick (auto-countdown)
		if (active_dialog_) {
			if (active_dialog_->tick()) {
				if (active_dialog_mode_ == dialog_mode::force_quit_prompt) {
					// Countdown expired, force quit
					editor_event quit_ev;
					quit_ev.type = event_type::force_quit;
					global_queue_.push(quit_ev);
				} else {
					resolve_dialog(active_dialog_->get_action());
				}
				needs_render = true;
			} else if (active_dialog_mode_ == dialog_mode::force_quit_prompt ||
				   active_dialog_mode_ == dialog_mode::copilot_connect ||
				   active_dialog_mode_ == dialog_mode::welcome) {
				needs_render = true;
			}
		}

		if (res != ERR) {
			editor_event ev;
			if (res == KEY_CODE_YES) {
				if (wch == KEY_MOUSE) {
					MEVENT event;
					if (getmouse(&event) == OK) {
						if (event.bstate & BUTTON1_PRESSED || event.bstate & BUTTON1_CLICKED) {
							ev.type = event_type::mouse_click;
							ev.mouse_x = event.x;
							ev.mouse_y = event.y;
							global_queue_.push(ev);
						} else if (event.bstate & BUTTON1_RELEASED) {
							ev.type = event_type::mouse_release;
							ev.mouse_x = event.x;
							ev.mouse_y = event.y;
							global_queue_.push(ev);
						} else if (event.bstate & REPORT_MOUSE_POSITION) {
							ev.type = event_type::mouse_drag;
							ev.mouse_x = event.x;
							ev.mouse_y = event.y;
							global_queue_.push(ev);
						} else if (event.bstate & BUTTON4_PRESSED) {
							ev.type = event_type::mouse_scroll_up;
							ev.mouse_x = event.x;
							ev.mouse_y = event.y;
							global_queue_.push(ev);
						} else if (event.bstate & BUTTON5_PRESSED) {
							ev.type = event_type::mouse_scroll_down;
							ev.mouse_x = event.x;
							ev.mouse_y = event.y;
							global_queue_.push(ev);
						}
					}
				} else {
					// Functional keys
					ev.type = event_type::key_press;
					ev.key_code = static_cast<int>(wch);
					global_queue_.push(ev);
				}
			} else {
				// Character or ESC sequence
				if (wch == 27) {    // ESC sequence
					timeout(0); // Non-blocking for sequence check
					wint_t next_wch;
					int next_res = get_wch(&next_wch);
					if (next_res != ERR && next_res != KEY_CODE_YES && next_wch == '[') {
						std::string seq;
						wint_t seq_wch;
						while (get_wch(&seq_wch) != ERR) {
							seq += (char)seq_wch;
							if (seq_wch == '~' || seq.length() > 10)
								break;
						}

						if (seq == "200~") {
							if (is_pasting_ && !paste_buffer_.empty()) {
								ev.type = event_type::paste;
								ev.payload = paste_buffer_;
								global_queue_.push(ev);
							}
							is_pasting_ = true;
							paste_buffer_.clear();
						} else if (seq == "201~") {
							is_pasting_ = false;
							if (!paste_buffer_.empty()) {
								ev.type = event_type::paste;
								ev.payload = paste_buffer_;
								global_queue_.push(ev);
								paste_buffer_.clear();
							}
						} else {
							if (is_pasting_) {
								paste_buffer_ += "\033[";
								paste_buffer_ += seq;
							} else {
								int key = 0;
								if (seq == "A")
									key = KEY_UP;
								else if (seq == "B")
									key = KEY_DOWN;
								else if (seq == "C")
									key = KEY_RIGHT;
								else if (seq == "D")
									key = KEY_LEFT;

								if (key != 0) {
									ev.type = event_type::key_press;
									ev.key_code = key;
									global_queue_.push(ev);
								}
							}
						}
					} else if (next_res != ERR) {
						// Alt + key
						if (is_pasting_) {
							paste_buffer_ += (char)27;
							char buf[8];
							int len = wctomb(buf, next_wch);
							if (len > 0)
								paste_buffer_.append(buf, len);
						} else {
							ev.type = event_type::key_press;
							ev.key_code = -static_cast<int>(next_wch);
							global_queue_.push(ev);
						}
					} else {
						if (is_pasting_) {
							paste_buffer_ += (char)27;
						} else {
							ev.type = event_type::key_press;
							ev.key_code = 27; // Bare ESC
							global_queue_.push(ev);
						}
					}
					timeout(50); // Restore 50ms timeout
				} else {
					// Printable character or UTF-8 sequence
					// Convert wide char to UTF-8 string
					char buf[8];
					int len = wctomb(buf, wch);
					if (len > 0) {
						if (is_pasting_) {
							paste_buffer_.append(buf, len);
						} else {
							ev.type = event_type::key_press;
							ev.key_code = static_cast<int>(wch);
							ev.utf8_char.assign(buf, len);
							global_queue_.push(ev);
						}
					}
				}
			}
		}

		while (auto ev = global_queue_.pop()) {
			dispatch(*ev);
			needs_render = true;
		}

		bool debug_exited = false;
		// Process each window's PTY/process events and cursor requirements.
		// We use a robust index-based loop instead of a range-based loop because processing events
		// (such as Alt-W / close window or opening a new subagent chat window) can modify the
		// windows_ vector (either erasing an element or appending a new one). An index-based check,
		// combined with searching for the raw pointer, ensures we do not access invalidated iterators
		// or dangling pointers if windows are deleted or shifted during iteration.
		for (size_t i = 0; i < windows_.size(); ) {
			window *raw_w = windows_[i].get();

			if (auto tw = dynamic_cast<ui::terminal_window *>(raw_w)) {
				if (tw->update_pty()) {
					needs_render = true;
				}
				if (tw->get_title() == "Debugger (GDB)" && !tw->is_alive()) {
					debug_exited = true;
				}
			}

			if (raw_w->process_events()) {
				needs_render = true;
			}

			// Verify that the window is still alive and located in the windows_ vector before
			// accessing it further, as process_events() could have synchronously triggered its deletion.
			bool alive = false;
			for (size_t j = 0; j < windows_.size(); ++j) {
				if (windows_[j].get() == raw_w) {
					alive = true;
					break;
				}
			}

			if (alive) {
				if (raw_w->needs_cursor()) {
					needs_cursor_render = true;
					raw_w->clear_needs_cursor();
				}
				++i;
			}
			// If the window was deleted, elements shifted down so we do not increment the index i.
		}

		if (debug_exited) {
			for (auto it = windows_.begin(); it != windows_.end();) {
				if ((*it)->get_title() == "Run Output" || (*it)->get_title() == "Debugger (GDB)") {
					if (auto tw = dynamic_cast<ui::terminal_window *>(it->get())) {
						tw->stop_process();
					}
					it = windows_.erase(it);
					needs_render = true;
				} else {
					++it;
				}
			}
			update_window_layout();
			if (!windows_.empty()) {
				activate_window(0);
				set_focus(focus_target::window, "debugger_exit");
			} else {
				set_focus(focus_target::menu_bar, "debugger_exit");
			}
		}

		if (needs_render) {
			render(false);
		} else if (needs_cursor_render) {
			render(true);
		}

		// Calculate event processing duration and update accumulated latency metrics
		if (processed_event) {
			auto event_end = std::chrono::steady_clock::now();
			uint64_t duration_us =
			    static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::microseconds>(event_end - event_start).count());

			total_latency_us_ += duration_us;
			total_input_events_++;

			if (duration_us > max_latency_us_) {
				max_latency_us_ = duration_us;
			}
			if (duration_us < min_latency_us_) {
				min_latency_us_ = duration_us;
			}

			if (duration_us > 10000) {
				slow_events_count_10ms_++;
			}
			if (duration_us > 5000) {
				slow_events_count_5ms_++;
			}
			if (duration_us > 1000) {
				slow_events_count_1ms_++;
			}

			if (duration_us > 15000) {
				uint64_t end_log_seq = event_logger::get_instance().get_total_event_count();
				std::vector<std::string> slice = event_logger::get_instance().get_event_slice(start_log_seq, end_log_seq);

				std::string key_desc;
				if (res == KEY_CODE_YES) {
					key_desc = std::format("Special Key (code: {})", static_cast<int>(wch));
				} else {
					if (wch >= 32 && wch < 127) {
						key_desc = std::format("Char '{}'", static_cast<char>(wch));
					} else {
						key_desc = std::format("Char code {}", static_cast<int>(wch));
					}
				}

				latency_spike spike;
				spike.duration_ms = static_cast<double>(duration_us) / 1000.0;
				spike.key_code = (res == KEY_CODE_YES) ? static_cast<int>(wch) : static_cast<int>(wch);
				spike.key_desc = key_desc;
				spike.trace = slice;

				latency_spikes_.push_back(spike);

				// Also log details to the event logger itself so it goes to the log file
				event_logger::get_instance().log("LATENCY SPIKE: event '{}' took {:.3f} ms. Captured {} trace log lines.",
								 key_desc, spike.duration_ms, slice.size());
			}
		}
	}

	// Signal to all background threads that the main application is exiting
	project_manager::get_instance().set_exiting(true);

	// Save cursor and project history on exit
	for (const auto &doc : documents_) {
		if (doc && !doc->get_filename().empty() && doc->has_nondefault_filename() && !doc->is_read_only()) {
			history_manager::get_instance().set_cursor_pos(doc->get_filename(), doc->get_cursor_x(), doc->get_cursor_y());
		}
	}

	std::string project_root = project_manager::get_instance().get_project_root();
	if (!project_root.empty()) {
		std::vector<std::string> open_files;
		for (const auto &w : windows_) {
			auto doc = w->get_document();
			if (doc && !doc->get_filename().empty() && doc->has_nondefault_filename() && !doc->is_read_only()) {
				open_files.push_back(doc->get_filename());
			}
		}
		history_manager::get_instance().set_project_files(project_root, open_files);
	}

	history_manager::get_instance().save();
}

std::string focus_target_to_string(focus_target target)
{
	switch (target) {
		case focus_target::menu_bar:
			return "menu_bar";
		case focus_target::window:
			return "window";
		case focus_target::dialog:
			return "dialog";
		case focus_target::popup:
			return "popup";
	}
	return "unknown";
}

void editor::set_focus(focus_target target, const std::string &source)
{
	std::string target_name = focus_target_to_string(target);

	event_logger::get_instance().log("Focus change: {} -> {}", source, target_name);
	current_focus_ = target;
	needs_full_redraw_ = true;

	if (target == focus_target::menu_bar) {
		update_window_menu();
	}
}

bool editor::handle_k_block_key(int key)
{
	auto &logger = event_logger::get_instance();
	logger.log("K-block handling key: " + std::to_string(key));

	char c = 0;
	if (key > 0 && key <= 26) {
		c = static_cast<char>(key + 'a' - 1);
	} else if (key >= 0 && key < 256) {
		c = std::tolower(static_cast<char>(key));
	}

	if (c == 0)
		return false;

	// Find active window/doc
	std::shared_ptr<document> active_doc = get_active_doc();

	if (c == 'b') {
		logger.log("K-block: Set Selection Begin");
		if (!active_doc)
			return false;
		active_doc->set_selection_start();
		return true;
	} else if (c == 'k') {
		logger.log("K-block: Set Selection End");
		if (!active_doc)
			return false;
		active_doc->set_selection_end();
		return true;
	} else if (c == 'h') {
		logger.log("K-block: Clear Selection");
		if (!active_doc)
			return false;
		active_doc->clear_selection();
		return true;
	} else if (c == 'y') {
		logger.log("K-block: Delete Block");
		if (!active_doc)
			return false;
		active_doc->delete_selection();
		editor_event redraw_ev;
		redraw_ev.type = event_type::redraw;
		global_queue_.push(redraw_ev);
		return true;
	} else if (c == 'c') {
		logger.log("K-block: Copy Block");
		if (!active_doc)
			return false;
		active_doc->copy_selection();
		editor_event redraw_ev;
		redraw_ev.type = event_type::redraw;
		global_queue_.push(redraw_ev);
		return true;
	} else if (c == 'm') {
		logger.log("K-block: Move Block");
		if (!active_doc)
			return false;
		active_doc->move_selection();
		editor_event redraw_ev;
		redraw_ev.type = event_type::redraw;
		global_queue_.push(redraw_ev);
		return true;
	} else if (c == 'n') {
		logger.log("K-block: New Window");
		new_window("");
		return true;
	} else if (c == 'p') {
		logger.log("K-block: Compile File");
		editor_event ev;
		ev.type = event_type::compile_file;
		global_queue_.push(ev);
		return true;
	} else if (c == 'g') {
		logger.log("K-block: Next Error");
		editor_event err_ev;
		err_ev.type = event_type::next_error;
		global_queue_.push(err_ev);
		return true;
	} else if (c == 'e') {
		logger.log("K-block: Edit (Open File)");
		editor_event ev;
		ev.type = event_type::load;
		global_queue_.push(ev);
		return true;
	} else if (c == 'a') {
		logger.log("K-block: Save All");
		if (active_doc && active_doc->is_read_only()) {
			logger.log("Cannot save-all read-only buffer via hotkey.");
			return true;
		}
		editor_event ev;
		ev.type = event_type::save_all;
		global_queue_.push(ev);
		return true;
	} else if (c == 'r') {
		logger.log("K-block: Insert File");
		if (!active_doc)
			return false;
		active_dialog_ = create_file_dialog("Insert File", ".");
		active_dialog_mode_ = dialog_mode::insert_file;
		set_focus(focus_target::dialog, "menu_insert_file");
		return true;
	} else if (c == 't') {
		logger.log("K-block: Revert");
		editor_event ev;
		ev.type = event_type::revert;
		global_queue_.push(ev);
		return true;
	} else if (c == 'j') {
		logger.log("K-block: Format Paragraph");
		if (active_doc) {
			active_doc->format_paragraph();
		}
		return true;
	} else if (c == ']') {
		logger.log("K-block: Expand Selection (LSP)");
		if (active_doc && !active_doc->get_filename().empty()) {
			project_manager::get_instance().lsp_request_selection_range(active_doc->get_filename(), active_doc->get_cursor_y(),
										    active_doc->get_cursor_x());
		}
		return true;
	} else if (c == '[' || c == '{') {
		logger.log("K-block: Select Scope");
		if (active_doc) {
			active_doc->select_enclosing_scope();
			editor_event redraw_ev;
			redraw_ev.type = event_type::redraw;
			global_queue_.push(redraw_ev);
		}
		return true;
	} else if (c == 'd' || c == 's') {
		logger.log("K-block: Save File");
		if (!active_doc || active_doc->is_read_only()) {
			logger.log("Cannot save read-only or empty buffer via hotkey.");
			return true;
		}
		editor_event ev;
		ev.type = event_type::save;
		global_queue_.push(ev);
		return true;
	} else if (c == 'w') {
		logger.log("K-block: Write (Save As)");
		if (!active_doc || active_doc->is_read_only()) {
			logger.log("Cannot save-as read-only or empty buffer via hotkey.");
			return true;
		}
		editor_event ev;
		ev.type = event_type::write_block;
		global_queue_.push(ev);
		return true;
	} else if (c == 'q') {
		logger.log("K-block: Quit (Abort)");
		editor_event quit_ev;
		quit_ev.type = event_type::quit;
		global_queue_.push(quit_ev);
		return true;
	} else if (c == 'x') {
		logger.log("K-block: Force Exit");
		editor_event quit_ev;
		quit_ev.type = event_type::force_quit;
		global_queue_.push(quit_ev);
		return true;
	} else if (c == 'f') {
		logger.log("K-block: Find (Status Bar Prompt)");
		active_mode_ = input_mode::searching;
		search_input_buffer_ = "";
		return true;
	} else if (c == 'l') {
		logger.log("K-block: Go to Line (Status Bar Prompt)");
		active_mode_ = input_mode::going_to_line;
		line_input_buffer_ = "";
		return true;
	} else if (c == 'u') {
		logger.log("K-block: Top of File");
		if (!active_doc)
			return false;
		active_doc->move_to_top();
		return true;
	} else if (c == 'v') {
		logger.log("K-block: End of File");
		if (!active_doc)
			return false;
		active_doc->move_to_bottom();
		return true;
	} else if (c == 'z') {
		logger.log("K-block: Zap Trailing Whitespace");
		if (active_doc) {
			active_doc->trim_trailing_whitespace();
			editor_event redraw_ev;
			redraw_ev.type = event_type::redraw;
			global_queue_.push(redraw_ev);
		}
		return true;
	}

	return false;
}

void editor::render(bool cursor_only)
{
	window *active_win = get_active_window();
	bool vp_changed = false;

	if (!cursor_only) {
		touchwin(stdscr);
		curs_set(0); // Default to hidden

		// Paint desktop background with dithered pattern
		attron(COLOR_PAIR(9));
		for (int y = 1; y < LINES - 1; ++y) {
			move(y, 0);
			for (int x = 0; x < COLS; ++x) {
				addstr("▒");
			}
		}
		attroff(COLOR_PAIR(9));

		// 2. Windows (Z-Index Managed)
		// Create a list of raw pointers to sort
		std::vector<window *> sorted_windows;
		for (auto &w : windows_) {
			sorted_windows.push_back(w.get());
		}

		// Sort: highest priority first. If priority is equal, newest timestamp first.
		std::sort(sorted_windows.begin(), sorted_windows.end(), [active_win](window *a, window *b) {
			int priority_a = (a == active_win) ? 9999 : a->get_display_priority();
			int priority_b = (b == active_win) ? 9999 : b->get_display_priority();

			if (priority_a != priority_b) {
				return priority_a > priority_b;
			}
			return a->get_last_active_timestamp() > b->get_last_active_timestamp();
		});

		// Occlusion culling: Assume visible, hide if fully covered by earlier (higher priority) windows.
		for (size_t i = 0; i < sorted_windows.size(); ++i) {
			window *w = sorted_windows[i];
			w->set_visible(true); // Default to visible

			// Check if fully covered by any single window above it
			for (size_t j = 0; j < i; ++j) {
				window *above = sorted_windows[j];
				if (above->is_visible() && w->get_x() >= above->get_x() && w->get_y() >= above->get_y() &&
				    w->get_x() + w->get_width() <= above->get_x() + above->get_width() &&
				    w->get_y() + w->get_height() <= above->get_y() + above->get_height()) {
					w->set_visible(false);
					break;
				}
			}
		}

		// Draw backwards (lowest priority first, so highest priority is on top)
		for (auto it = sorted_windows.rbegin(); it != sorted_windows.rend(); ++it) {
			if ((*it)->is_visible()) {
				if ((*it)->draw(false)) {
					vp_changed = true;
				}
			}
		}

		top_menu_.draw();
	} else {
		if (active_win && active_win->is_visible()) {
			if (active_win->draw(true)) {
				vp_changed = true;
			}
		}
	}

	std::string debug_out;
	int cur_x = -1, cur_y = -1;

	if (debug_mode_) {
		auto &logger = event_logger::get_instance();
		auto msg = logger.get_latest_matching_message(debug_string_);
		if (msg) {
			debug_out = ">>" + *msg + "<<";
		}
	}

	if (active_win) {
		cur_x = active_win->get_cursor_x();
		cur_y = active_win->get_cursor_y();
	}

	std::string status_help = debug_out;
	switch (active_mode_) {
		case input_mode::k_block:
			status_help = get_k_block_status_help();
			break;
		case input_mode::q_block:
			status_help = "Q-Block: F:Find A:Replace H:History";
			break;
		case input_mode::p_block:
			status_help = "Agent: (R)eformat (F)ix Warn (C)omment Re(v)iew (T)ODOs (S)pell (U)ser: _";
			break;
		case input_mode::inline_agent:
			status_help = "Agent Task: " + inline_agent_input_buffer_ + "_";
			break;
		case input_mode::searching: {
			std::string suggestion = get_search_autocomplete();
			if (!suggestion.empty() && suggestion != search_input_buffer_) {
				status_help =
				    "Search for: " + search_input_buffer_ + "[" + suggestion.substr(search_input_buffer_.length()) + "]";
			} else {
				status_help = "Search for: " + search_input_buffer_ + "_";
			}
			break;
		}
		case input_mode::search_options:
			status_help = "Options (I R B K): " + search_options_buffer_ + "_";
			break;
		case input_mode::going_to_line:
			status_help = "Go to line: " + line_input_buffer_ + "_";
			break;
		case input_mode::vim:
			status_help = ":" + vim_input_buffer_ + "_";
			break;
		case input_mode::replace_prompt:
			status_help = "Replace? (Y)es / (N)o / (A)ll / (Q)uit";
			break;
		case input_mode::normal:
			if (active_win) {
				status_help = active_win->get_status_help();
			}
			break;
	}

	std::string diag_text = "";
	std::function<void()> diag_click_handler = nullptr;
	if (active_win && active_win->get_document()) {
		auto doc = active_win->get_document();
		for (const auto &diag : doc->get_lsp_diagnostics()) {
			if (cur_y > diag.range.start_y && cur_y < diag.range.end_y) {
				diag_text = diag.message;
				break;
			} else if (cur_y == diag.range.start_y && cur_y == diag.range.end_y) {
				if (cur_x >= diag.range.start_x && cur_x <= diag.range.end_x) {
					diag_text = diag.message;
					break;
				}
			} else if (cur_y == diag.range.start_y && cur_x >= diag.range.start_x) {
				diag_text = diag.message;
				break;
			} else if (cur_y == diag.range.end_y && cur_x <= diag.range.end_x) {
				diag_text = diag.message;
				break;
			}
		}

		// If no LSP diagnostic, check for GCC build errors
		if (diag_text.empty()) {
			auto build_err = build_error_manager::get_instance().find_error_at(doc->get_safe_filename(), cur_y);
			if (build_err) {
				diag_text = (build_err->is_warning ? "[Warning] " : "[Error] ") + build_err->message;
			}
		}

		// If no LSP diagnostic and no build error, check for code review items
		if (diag_text.empty()) {
			std::string proj_root = project_manager::get_instance().get_project_root();
			auto file_matches = [&proj_root](const std::string &doc_filename, const std::string &item_filename) -> bool {
				if (doc_filename.empty() || item_filename.empty())
					return false;
				if (doc_filename == item_filename)
					return true;
				std::filesystem::path doc_path(doc_filename);
				std::filesystem::path item_path(item_filename);
				std::filesystem::path abs_doc =
				    doc_path.is_absolute() ? doc_path : std::filesystem::path(proj_root) / doc_path;
				std::filesystem::path abs_item =
				    item_path.is_absolute() ? item_path : std::filesystem::path(proj_root) / item_path;
				return abs_doc.lexically_normal() == abs_item.lexically_normal();
			};

			auto all_reviews = codereview_manager::get_instance().list_code_review_items();
			for (const auto &item : all_reviews) {
				if (item.line_number == cur_y + 1 &&
				    (item.state == "new" || item.state == "confirmed" || item.state == "disputed") &&
				    file_matches(doc->get_safe_filename(), item.filename)) {
					diag_text = std::format("[Code Review #{}] ({}) {}", item.id, item.severity, item.summary);
					diag_click_handler = [this, item_id = item.id]() {
						editor_event open_ev;
						open_ev.type = event_type::open_codereview_viewer;
						open_ev.key_code = item_id;
						this->global_queue_.push(open_ev);
					};
					break;
				}
			}
		}
	}

	if (!diag_text.empty()) {
		set_status_message(diag_text, status_priorities::WARNING, std::chrono::milliseconds::max(), diag_click_handler);
	} else {
		clear_status_message(status_priorities::WARNING);
	}

	// Find active agent status
	std::string agent_status_text = "";
	for (const auto &win : windows_) {
		if (auto aw = dynamic_cast<agent_window *>(win.get())) {
			auto agent = aw->get_agent();
			if (agent && agent->get_status() != agentlib::agent_status::idle) {
				agent_status_text =
				    "Agent: " + agentlib::agent_status_to_string(agent->get_status(), agent->get_current_tool());
				break;
			}
		}
	}

	if (!agent_status_text.empty()) {
		set_status_message(agent_status_text, status_priorities::INFO);
	} else {
		clear_status_message(status_priorities::INFO);
	}

	std::string combined_hover = get_active_status_message();

	bool has_history = false;
	auto active_doc = get_active_doc();
	if (active_doc && active_doc->get_undo_count() > 0) {
		has_history = true;
	}
	bottom_status_.draw(status_help, combined_hover, cur_x, cur_y, has_history);

	if (active_dialog_) {
		active_dialog_->draw();
	}

	if (active_popup_) {
		active_popup_->draw();
	}

	if (needs_full_redraw_) {
		redrawwin(stdscr);
		needs_full_redraw_ = false;
	} else if (vp_changed) {
		touchwin(stdscr);
	}

	curs_set(0);
	refresh();

	// Only show cursor if we are in window focus and NOT in a modal state
	if (current_focus_ == focus_target::window && !active_dialog_ && !active_popup_ && active_mode_ == input_mode::normal) {
		if (active_win) {
			active_win->set_cursor_position();
			if (active_win->is_cursor_visible()) {
				curs_set(1);
			} else {
				curs_set(0);
			}
		}
	}
}

bool editor::apply_live_edits(const std::string &safe_path, const std::string &edits_json_payload)
{
	editor_event ev;
	ev.type = event_type::apply_edits;
	ev.payload = safe_path + "\n" + edits_json_payload;
	global_queue_.push(ev);
	return true;
}

void editor::save_all_documents()
{
	for (auto &doc : documents_) {
		if (doc && doc->is_modified() && !doc->get_filename().empty()) {
			doc->save();
			history_manager::get_instance().add_file(doc->get_filename());
			for (auto &w : windows_) {
				if (w->get_document() == doc) {
					w->set_title(doc->get_filename());
					break;
				}
			}
		}
	}
	update_window_menu();
}

void editor::check_files_changed()
{
	auto doc = get_active_doc();
	if (!doc || doc->get_filename().empty() || active_dialog_ || active_popup_)
		return;

	if (doc->check_disk_changed()) {
		active_dialog_ = create_reload_prompt_dialog(doc->get_filename());
		active_dialog_mode_ = dialog_mode::reload_prompt;
		set_focus(focus_target::dialog, "reload_prompt");
		editor_event redraw_ev;
		redraw_ev.type = event_type::redraw;
		global_queue_.push(redraw_ev);
	}
}

std::string editor::get_k_block_status_help() const
{
	auto active_doc = get_active_doc();

	struct k_block_option {
		std::string label;
		int priority;
		size_t original_idx;
		std::function<bool(const editor &, const std::shared_ptr<document> &)> is_applicable;
	};

	std::vector<k_block_option> options = {
	    {"^B:Beg", 30, 0, [](const editor &, const std::shared_ptr<document> &doc) { return doc != nullptr; }},
	    {"^K:End", 30, 1, [](const editor &, const std::shared_ptr<document> &doc) { return doc != nullptr; }},
	    {"^H:Hide", 30, 2, [](const editor &, const std::shared_ptr<document> &doc) { return doc && doc->has_selection(); }},
	    {"^Y:Del", 30, 3, [](const editor &, const std::shared_ptr<document> &doc) { return doc && doc->has_selection(); }},
	    {"^C:Copy", 30, 4, [](const editor &, const std::shared_ptr<document> &doc) { return doc && doc->has_selection(); }},
	    {"^M:Move", 30, 5, [](const editor &, const std::shared_ptr<document> &doc) { return doc && doc->has_selection(); }},
	    {"^U:Top", 20, 6, [](const editor &, const std::shared_ptr<document> &doc) { return doc != nullptr; }},
	    {"^V:End", 20, 7, [](const editor &, const std::shared_ptr<document> &doc) { return doc != nullptr; }},
	    {"^F:Find", 20, 8, [](const editor &, const std::shared_ptr<document> &doc) { return doc != nullptr; }},
	    {"^L:Line", 20, 9, [](const editor &, const std::shared_ptr<document> &doc) { return doc != nullptr; }},
	    {"^S:Save", 30, 10, [](const editor &, const std::shared_ptr<document> &doc) { return doc && doc->is_modified(); }},
	    {"^A:SaveAll", 10, 11,
	     [](const editor &ed, const std::shared_ptr<document> &) {
		     for (const auto &d : ed.documents_) {
			     if (d && d->is_modified())
				     return true;
		     }
		     return false;
	     }},
	    {"^W:Write", 10, 12, [](const editor &, const std::shared_ptr<document> &doc) { return doc != nullptr; }},
	    {"^R:Insert", 10, 13, [](const editor &, const std::shared_ptr<document> &doc) { return doc != nullptr; }},
	    {"^J:Format", 10, 14, [](const editor &, const std::shared_ptr<document> &doc) { return doc != nullptr; }},
	    {"^Z:Zap", 10, 15, [](const editor &, const std::shared_ptr<document> &doc) { return doc != nullptr; }},
	    {"^N:New", 10, 16, [](const editor &, const std::shared_ptr<document> &) { return true; }},
	    {"^P:Compile", 10, 17, [](const editor &, const std::shared_ptr<document> &doc) { return doc != nullptr; }},
	    {"^G:Error", 10, 18, [](const editor &, const std::shared_ptr<document> &doc) { return doc != nullptr; }},
	    {"^Q:Quit", 30, 19, [](const editor &, const std::shared_ptr<document> &) { return true; }},
	    {"^X:SaveExit", 30, 20, [](const editor &, const std::shared_ptr<document> &doc) { return doc != nullptr; }}};

	// 1. Filter by applicability
	std::vector<k_block_option> applicable;
	for (const auto &opt : options) {
		if (opt.is_applicable(*this, active_doc)) {
			applicable.push_back(opt);
		}
	}

	// 2. Sort applicable options by priority descending
	// Tie-breaker: original_idx (ascending) to keep sorting stable and deterministic
	std::sort(applicable.begin(), applicable.end(), [](const k_block_option &a, const k_block_option &b) {
		if (a.priority != b.priority) {
			return a.priority > b.priority;
		}
		return a.original_idx < b.original_idx;
	});

	// Helper to calculate printed length (excluding '^' carets)
	auto get_printed_len = [](const std::string &s) {
		int len = 0;
		for (char c : s) {
			if (c != '^')
				len++;
		}
		return len;
	};

	// 3. Greedily add options that fit within COLS - 2
	int limit = COLS - 2;
	if (limit < 9)
		limit = 9;

	std::vector<k_block_option> selected;
	for (const auto &opt : applicable) {
		std::vector<k_block_option> temp = selected;
		temp.push_back(opt);

		std::sort(temp.begin(), temp.end(),
			  [](const k_block_option &a, const k_block_option &b) { return a.original_idx < b.original_idx; });

		int total_printed_len = 9; // length of "K-Block: "
		for (size_t i = 0; i < temp.size(); ++i) {
			if (i > 0)
				total_printed_len += 1;
			total_printed_len += get_printed_len(temp[i].label);
		}

		if (total_printed_len <= limit) {
			selected = temp;
		}
	}

	// Final sort by original_idx
	std::sort(selected.begin(), selected.end(),
		  [](const k_block_option &a, const k_block_option &b) { return a.original_idx < b.original_idx; });

	std::string result = "K-Block:";
	for (const auto &opt : selected) {
		result += " " + opt.label;
	}

	return result;
}

void editor::set_status_message(const std::string &message, int priority, std::chrono::milliseconds duration,
				std::function<void()> click_handler)
{
	status_message msg;
	msg.text = message;
	if (duration == std::chrono::milliseconds::max()) {
		msg.expiry = std::chrono::steady_clock::time_point::max();
	} else {
		msg.expiry = std::chrono::steady_clock::now() + duration;
	}
	msg.click_handler = click_handler;
	active_status_messages_[priority] = msg;
}

void editor::clear_status_message(int priority)
{
	active_status_messages_.erase(priority);
}

const editor::status_message *editor::get_active_status_message_obj() const
{
	auto now = std::chrono::steady_clock::now();
	for (auto it = active_status_messages_.rbegin(); it != active_status_messages_.rend(); ++it) {
		if (now < it->second.expiry && !it->second.text.empty()) {
			return &it->second;
		}
	}
	return nullptr;
}

std::string editor::get_active_status_message() const
{
	auto obj = get_active_status_message_obj();
	return obj ? obj->text : "";
}

void editor::handle_status_bar_click(int mouse_x)
{
	(void)mouse_x;
	auto active_msg_obj = get_active_status_message_obj();
	if (active_msg_obj && active_msg_obj->click_handler) {
		active_msg_obj->click_handler();
	} else {
		// Fallback: Open general code review viewer
		editor_event open_ev;
		open_ev.type = event_type::open_codereview_viewer;
		open_ev.key_code = -1;
		global_queue_.push(open_ev);
	}
}

/**
 * Prints the interactive event response latency metrics to the console.
 * Calculates average, minimum, maximum latencies, and computes percentages
 * of events exceeding specific performance thresholds (1ms, 5ms, 10ms).
 */
void editor::print_latency_report() const
{
	if (total_input_events_ == 0) {
		std::cout << "\nNo interactive input events were processed during this session.\n";
		return;
	}

	double avg_ms = (static_cast<double>(total_latency_us_) / total_input_events_) / 1000.0;
	double max_ms = static_cast<double>(max_latency_us_) / 1000.0;
	double min_ms = static_cast<double>(min_latency_us_) / 1000.0;

	double pct_1ms = (static_cast<double>(slow_events_count_1ms_) / total_input_events_) * 100.0;
	double pct_5ms = (static_cast<double>(slow_events_count_5ms_) / total_input_events_) * 100.0;
	double pct_10ms = (static_cast<double>(slow_events_count_10ms_) / total_input_events_) * 100.0;

	std::cout << "\n"
		  << "--------------------------------------------------\n"
		  << "Turbostar Interactive Latency Report\n"
		  << "--------------------------------------------------\n"
		  << std::format("Total input events processed: {}\n", total_input_events_)
		  << std::format("Minimum processing latency:   {:.3f} ms\n", min_ms)
		  << std::format("Average processing latency:   {:.3f} ms\n", avg_ms)
		  << std::format("Maximum processing latency:   {:.3f} ms\n", max_ms) << "\n"
		  << "Latency Distribution:\n"
		  << std::format("  Events taking >  1 ms:      {} ({:.2f}%)\n", slow_events_count_1ms_, pct_1ms)
		  << std::format("  Events taking >  5 ms:      {} ({:.2f}%)\n", slow_events_count_5ms_, pct_5ms)
		  << std::format("  Events taking > 10 ms:      {} ({:.2f}%)\n", slow_events_count_10ms_, pct_10ms)
		  << "--------------------------------------------------\n";

	if (!latency_spikes_.empty()) {
		std::cout << "Captured Latency Spikes (> 15 ms):\n";
		size_t print_count = std::min(latency_spikes_.size(), size_t(5));
		for (size_t i = 0; i < print_count; ++i) {
			const auto &spike = latency_spikes_[i];
			std::cout << std::format("  Spike #{} - Key: '{}', Latency: {:.3f} ms\n", i + 1, spike.key_desc, spike.duration_ms);
			std::cout << "    Trace logs during this event:\n";
			if (spike.trace.empty()) {
				std::cout << "      (No logs recorded)\n";
			} else {
				for (const auto &line : spike.trace) {
					std::cout << "      " << line << "\n";
				}
			}
		}
		if (latency_spikes_.size() > 5) {
			std::cout << std::format("  ... and {} more spikes > 15 ms (logged to event log).\n", latency_spikes_.size() - 5);
		}
		std::cout << "--------------------------------------------------\n";
	}
}

static void collect_agents_recursive(const std::shared_ptr<agentlib::ai_agent> &agent,
				     std::vector<std::shared_ptr<agentlib::ai_agent>> &out_agents, std::unordered_set<int> &seen_ids)
{
	if (!agent || agent->get_status() == agentlib::agent_status::dead) {
		return;
	}
	if (seen_ids.count(agent->get_id())) {
		return;
	}
	seen_ids.insert(agent->get_id());
	out_agents.push_back(agent);
	for (const auto &subagent : agent->get_subagents()) {
		collect_agents_recursive(subagent, out_agents, seen_ids);
	}
}

std::vector<std::shared_ptr<agentlib::ai_agent>> editor::get_all_active_agents() const
{
	std::vector<std::shared_ptr<agentlib::ai_agent>> active_agents;
	std::unordered_set<int> seen_ids;

	// 1. Gather root agents from active agent windows
	for (const auto &win : windows_) {
		if (auto *agent_win = dynamic_cast<agent_window *>(win.get())) {
			if (auto agent = agent_win->get_agent()) {
				collect_agents_recursive(agent, active_agents, seen_ids);
			}
		}
	}

	// 2. Gather headless background agents
	for (const auto &agent : headless_agents_) {
		collect_agents_recursive(agent, active_agents, seen_ids);
	}

	return active_agents;
}

void editor::save_search_persistence()
{
	session_manager::get_instance().set_last_search_query(current_search_.query);
	session_manager::get_instance().set_last_replace_query(current_search_.replacement);
	session_manager::get_instance().save();
}
